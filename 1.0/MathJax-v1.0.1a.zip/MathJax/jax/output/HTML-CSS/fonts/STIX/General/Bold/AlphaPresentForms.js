/*
 *  ../SourceForge/trunk/mathjax/jax/output/HTML-CSS/fonts/STIX/General/Bold/AlphaPresentForms.js
 *  
 *  Copyright (c) 2010 Design Science, Inc.
 *
 *  Part of the MathJax library.
 *  See http://www.mathjax.org for details.
 * 
 *  Licensed under the Apache License, Version 2.0;
 *  you may not use this file except in compliance with the License.
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 */

MathJax.Unpack([
  ['MathJax.Hub.Insert','(MathJax.OutputJax["HTML-CSS"].','FONTDATA.FONTS["STIXGeneral-bold"],{64256:[691,0,610,15,666],64257:[691,0,556,14,536],64258:[691,0,556,15,535],64259',':[691,0,833,15,','813],64260',3,'812]});MathJax.Ajax.loadComplete',1,'fontDir+"/General/Bold/AlphaPresentForms.js");']
]);

