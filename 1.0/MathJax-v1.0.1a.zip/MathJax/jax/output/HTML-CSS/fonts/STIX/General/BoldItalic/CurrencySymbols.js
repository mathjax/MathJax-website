/*
 *  ../SourceForge/trunk/mathjax/jax/output/HTML-CSS/fonts/STIX/General/BoldItalic/CurrencySymbols.js
 *  
 *  Copyright (c) 2010 Design Science, Inc.
 *
 *  Part of the MathJax library.
 *  See http://www.mathjax.org for details.
 * 
 *  Licensed under the Apache License, Version 2.0;
 *  you may not use this file except in compliance with the License.
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 */

MathJax.Unpack([
  ['MathJax.Hub.Insert','(MathJax.OutputJax["HTML-CSS"].','FONTDATA.FONTS["STIXGeneral-bold-italic"],{8355:[669,0,668,-13,661],8356:[683,12,500,-32,510],8359:[669,13,1229,-28,1173],8364:[681,17,562,34,546]});MathJax.Ajax.loadComplete',1,'fontDir+"/General/BoldItalic/CurrencySymbols.js");']
]);

