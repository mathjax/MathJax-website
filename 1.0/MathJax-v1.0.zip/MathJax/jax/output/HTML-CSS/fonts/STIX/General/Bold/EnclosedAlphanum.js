/*
 *  ../SourceForge/trunk/mathjax/jax/output/HTML-CSS/fonts/STIX/General/Bold/EnclosedAlphanum.js
 *  
 *  Copyright (c) 2010 Design Science, Inc.
 *
 *  Part of the MathJax library.
 *  See http://www.mathjax.org for details.
 * 
 *  Licensed under the Apache License, Version 2.0;
 *  you may not use this file except in compliance with the License.
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 */

MathJax.Unpack([
  ['MathJax.Hub.Insert','(MathJax.OutputJax["HTML-CSS"].','FONTDATA.FONTS["STIXGeneral-bold"],{9312',':[690,19,695,0,695],','9313',3,'9314',3,'9315',3,'9316',3,'9317',3,'9318',3,'9319',3,'9320',3,'9398',3,'9399',3,'9400',3,'9401',3,'9402',3,'9403',3,'9404',3,'9405',3,'9406',3,'9407',3,'9408',3,'9409',3,'9410',3,'9411',3,'9412',3,'9413',3,'9414',3,'9415',3,'9416',3,'9417',3,'9418',3,'9419',3,'9420',3,'9421',3,'9422',3,'9423',3,'9424',3,'9425',3,'9426',3,'9427',3,'9428',3,'9429',3,'9430',3,'9431',3,'9432',3,'9433',3,'9434',3,'9435',3,'9436',3,'9437',3,'9438',3,'9439',3,'9440',3,'9441',3,'9442',3,'9443',3,'9444',3,'9445',3,'9446',3,'9447',3,'9448',3,'9449',3,'9450:[690,19,695,0,695]});MathJax.Ajax.loadComplete',1,'fontDir+"/General/Bold/EnclosedAlphanum.js");']
]);

